--~ DROP TABLE IF EXISTS `#__tjvendors_vendors`;

--~ DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_tjvendors.%');
